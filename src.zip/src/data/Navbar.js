export const NavbarData = [
  {
    path: "/",
    title: "Home",
  },
  {
    path: "/notes",
    title: "Notes",
  },
];
